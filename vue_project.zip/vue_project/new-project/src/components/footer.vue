<template>
    <footer>
        <p>CopyRight &copy; 2021</p>
        <a href="/About">About</a>
    </footer>
</template>

<style>
    a{
        color: #333;
    }
    footer{
        margin-top: 20px;
        text-align: center;
    }
</style>